// TODO: Optimize the reading so it can read the world pbf

package main

import (
	"context"
	"log/slog"
	"os"
	"runtime"
	"strconv"
	"time"

	"github.com/gosuri/uiprogress"
	geojson "github.com/paulmach/go.geojson"
	"github.com/paulmach/osm"
	"github.com/paulmach/osm/osmpbf"
)

const PBF_FILE_PATH = "../osm_data/antarctica-latest.osm.pbf"
const GJSON_FILE_PATH = "../osm_data/antarctica.geojson"

// main is the entry point of the program.
// It opens a PBF file, scans its contents, extracts coastline data,
// and creates a GeoJSON file containing the coastline features.
// The function also logs various information such as file size, number of nodes read,
// and the total time taken for the operation.
func main() {
	var start = time.Now()

	f, err := os.Open(PBF_FILE_PATH)
	if err != nil {
		slog.Error("Error opening PBF File!")
		panic(err)
	}
	defer f.Close()

	osm_file_stats, err := f.Stat()

	if err != nil {
		slog.Error("Error retrieving PBF File stats!")
		panic(err)
	}

	osm_file_size := osm_file_stats.Size()

	slog.Info("OSM File Size: " + strconv.FormatInt(osm_file_size/(1024*1024), 10) + " MB")

	scanner := osmpbf.New(context.Background(), f, runtime.NumCPU())
	defer scanner.Close()

	featureCollection := geojson.NewFeatureCollection()

	nodes_map := make(map[osm.NodeID]*osm.Node)
	info_counter := make(map[string]int)

	scanner.SkipRelations = true

	slog.Info("Starting scan...")
	uiprogress.Start()
	bar := uiprogress.AddBar(int(osm_file_size)) // Add a new bar

	for scanner.Scan() {

		o := scanner.Object()
		bar.Set(int(scanner.FullyScannedBytes()))

		switch o := o.(type) {

		case *osm.Node:
			nodes_map[o.ID] = o
			info_counter["nodes"]++

		case *osm.Way:
			if o.Tags.Find("natural") == "coastline" {
				geometry := geojson.NewLineStringGeometry(make([][]float64, len(o.Nodes)))
				for i, node := range o.Nodes {
					geometry.LineString[i] = []float64{nodes_map[node.ID].Lon, nodes_map[node.ID].Lat}
				}
				feature := geojson.NewFeature(geometry)
				feature.SetProperty("id", o.ID)
				featureCollection.AddFeature(feature)
			}
		}
	}

	scanErr := scanner.Err()
	if scanErr != nil {
		panic(scanErr)
	}

	geojsonData, err := featureCollection.MarshalJSON()
	if err != nil {
		slog.Error("Error marshaling GeoJSON: " + err.Error())
	}

	err = os.WriteFile(GJSON_FILE_PATH, geojsonData, 0644)
	if err != nil {
		slog.Error("Error writing GeoJSON file: " + err.Error())
	}

	slog.Info("GeoJSON file created successfully.")

	slog.Info("GeoJSON file created at: " + GJSON_FILE_PATH)
	slog.Info("Nodes read: " + strconv.Itoa(info_counter["nodes"]))
	slog.Info("Total time taken: " + time.Since(start).String())

}
